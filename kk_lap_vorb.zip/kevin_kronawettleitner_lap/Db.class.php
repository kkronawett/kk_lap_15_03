<?php 
class Db{
   private $pdo;

   //constructor für datenbank connection
   function __construct($host, $dbname, $user, $pw) {
      try{
         $pdo = new PDO('mysql:host='.$host.';dbname='.$dbname, $user, $pw);
      }catch(Exception $e){
         echo "DB Connection refused";
      }
      
      $this->pdo = $pdo;
    }








//printed abhängig die im Parameter übergebenen daten
public function getAll($tables){
   /*
   $sql = "SELECT * FROM user";
   foreach ($this->pdo->query($sql) as $row) {
      echo $row['Host']."<br />";
      echo $row['User']."<br />";
      echo $row['Password']."<br /><br />";
   }*/

   $sql = "SELECT";
   $sql_attributes="";
   $sql_joins="";
   foreach($tables as $table){
      $sql_attributes.=" ".$this->attributes_to_string($table).",";
      $sql_joins.=" ".$this->string_to_join($table);
   }
   $sql.=substr($sql_attributes, 0, strlen($sql_attributes)-1)." ".$sql_joins;
   $stmt = $this->pdo->prepare($sql);
   $stmt->execute(array(1)); 
   $rslt = $stmt->fetchAll();
   return $rslt;
}

//macht einen sql verwendbaren string aus attributen
private function attributes_to_string($table){
   $name = strtolower($table->get_table_name());
   $attributes = $table->get_attributes();
   for($i=0;$i<count($attributes);$i++){
      $attributes[$i]=$name.".".$attributes[$i];
   }
   return implode(", ",$attributes);
}

//macht einen sql verwendbaren string aus "joins"
private function string_to_join($table){
   $name = $table->get_table_name();
   $string=$table->get_join()." ".$name." ".strtolower($name);
   if($table->get_join()!="FROM"){
      $string.=" ".$table->get_join_on();
   }
   return $string;
}
}

?>