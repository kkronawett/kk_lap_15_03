<!-- Navigationsleiste -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" name="/homepage.php" aria-current="page" href="./homepage.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" name="/add.php" href="./add.php">Add</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Blobb</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"
                    >Brä</a
                    >
                </li>
            </ul>
        </div>
    </div>
</nav>