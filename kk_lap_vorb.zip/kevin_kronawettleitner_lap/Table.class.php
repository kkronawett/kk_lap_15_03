<?php class Table{
    private $join;
    private $attributes = array();
    private $table_name;
    private $join_on;

    //constructor für Table class und die get und set functions um die werte im objekt ändern zu können
    function __construct($table_name, $attributes, $join, $join_on){
        $this->table_name=$table_name;
        $this->attributes=$attributes;
        $this->join=$join;
        $this->join_on=$join_on;
    }
    public function get_join(){
        return $this->join;
    }
    public function get_join_on(){
        return $this->join_on;
    }
    public function get_table_name(){
        return $this->table_name;
    }
    public function get_attributes(){
        return $this->attributes;
    }
    public function set_join($join){
        $this->join=$join;
    }
    public function set_join_on($join_on){
        $this->join_on=$join_on;
    }
    public function set_table_name($table_name){
        $this->table_name=$table_name;
    }
    public function set_attributes($attributes){
        $this->attributes=$attributes;
    }
}
?>