<?php 
class Tabelle{

  public function print_table($tabelle){
    $keys = array_keys($tabelle[0]);
    echo "<table class='table'>";
    $this->print_table_head($keys);
    $this->print_table_body($tabelle);
  
    echo "</table>";
  }
  
  private function print_table_head($keys){
  echo "<thead><tr>";
  foreach($keys as $key){
    if(!is_int($key)){
      echo "<th scope='col'>".$key."</th>";
    }

  }
  echo "</thead><tr>";
  }
  private function print_table_body($array){
    echo "<tbody>";
    foreach($array as $row){
      echo "<tr>";
      foreach($row as $key => $value){
        if(!is_int($key)){
          echo "<td>".$value."</td>";
        }
      }
      echo "</tr>";
    }
    echo "</tbody>";
  }
}
?>
