<?php
include "Db.class.php";
include "Table.class.php";
include "Tabelle.class.php";

$db = new Db("localhost", "mydb", "root", "qwepoi10");

$person_table = new Table("person", array("id","sec_name AS '2nd Name'", "first_name",  "last_name"), "FROM","");
$movie_director_table = new Table("movie_director", array("person_id", "movie_id", "id"), "JOIN","ON movie_director.person_id=person.id");

$rslt = $db->getAll(array($person_table, $movie_director_table));

include 'head.php';
include 'nav.php';
?>
<html lang="en">


<body>

<?php
$tabelle = new Tabelle();
$tabelle->print_table($rslt);
?>

</body>

</html>