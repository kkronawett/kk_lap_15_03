//Ausführung von Aktionen beim Start der Seite
$( document ).ready(function() {

    //setzt bei der navbar anhand vom pathname den "Button" für die Navigation auf active
    var loc_str = location.pathname;
    var loc_php_str = loc_str.substring(loc_str.lastIndexOf("/"))
    $("[name='"+loc_php_str+"']").addClass("active");
});